#include "Controller.h"

void Controller::setControllerListener( ControllerListener* mControllerListener )
{
    this->mControllerListener = mControllerListener;
}